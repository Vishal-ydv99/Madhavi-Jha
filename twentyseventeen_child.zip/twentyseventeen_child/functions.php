<?php 
define('MJT_CHILD','mjt_child');
function mjt_child_theme_style() {	
	wp_register_style( 'childtheme-style', get_stylesheet_directory_uri(). '/style.css', array(), '1.0.0' );
	wp_enqueue_style( 'childtheme-style');
	wp_enqueue_style( 'parent-style', get_template_directory_uri().'/style.css' );	
}
add_action( 'wp_enqueue_scripts', 'mjt_child_theme_style' , 10);

 if (function_exists('register_sidebar')) {  
         register_sidebar(array(  
          'name' => 'Header Top Right Widget',  
          'id'   => 'header-top-sidebar',  
          'description'   => 'Header Top Right Widget Area',  
          'before_widget' => '<div id="%1$s" class="widget %2$s">',  
          'after_widget'  => '</div>',  
          'before_title'  => '',  
          'after_title'   => ''  
         ));  
        }  


